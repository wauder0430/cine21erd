-- 전문가 + 전문가 리뷰
insert into Movie_Expert values (Movie_Expert_seq.nextval, '남선우');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[한때 나의 집이 되어준 사람에게 묻는 안부]', 6, 1, 1);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '조현나');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[안고 갈 추억으로 남길 수 있다]', 7, 2, 1);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '이용철');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[주동우 버전을 안 보고 갔어야 했다]', 6, 3, 1);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '유선아');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[소중했던 시절 인연에 흘려보내는 좋은 안녕]', 7, 4, 1);


insert into Movie_Expert values (Movie_Expert_seq.nextval, '최선');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[가짜 찬양단의 진짜 목적은]', 2, 5, 2);


insert into Movie_Expert values (Movie_Expert_seq.nextval, '송경원');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[증오와 분리를 넘어, 극장으로 연결되어, 다음 세대를 향해]', 7, 6, 3);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '이자연');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[판도라의 화려함을 벗어나 서사로 승부 보는 순간, 음 나는 여기까지!]', 6, 7, 3);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '이우빈');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[첨단과 고전 사이, 시네마의 유산을 몸소 지키려는 할리우드의 왕]', 8, 8, 3);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '김소미');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[진부함을 가장 눈부시게]', 6, 9, 3);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '박평식');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[포만감을 만끽했지만 식곤증도 빠르게]', 7, 10, 3);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[하나는 증명했다, 영화가 기술일지 몰라도 기술이 영화는 아니다]', 6, 3, 3);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '김철홍');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[골짜기를 넘어가버린 스펙터클. 더이상 재를 뿌리고 싶지 않다]', 6, 11, 3);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[속 빈 무드에도 살아남은 캐릭터들의 현란한 비주얼]', 4, 6, 4);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '이유채');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[진탕 속에서도 욕망하는 여자들은 앞을 향한다]', 5, 12, 4);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[케케묵은 서사와 겉멋으로는]', 4, 10, 4);


insert into Movie_Expert values (Movie_Expert_seq.nextval, '김경수');
insert into ExpertReview values (ExpertReview_seq.nextval, q'['신비아파트: 엔드게임'이라 해도 손색없는 팬 서비스, 세련된 비주얼에 오열(서브웨이 레시피는 덤)]', 7, 13, 5);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[포용, 이해의 태도를 겸비한 성장 서사가 반갑다]', 7, 2, 6);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[역차별에 정지한 시즌1보다 소수자의 역사를 찾는 시즌2가 더 '유토피아'적]', 7, 7, 6);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[성능 좋은 디즈니 산소호흡기2]', 6, 10, 6);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[여전히 재미있으나 좀 정신 사납다]', 6, 3, 6);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[충돌할수록 충만해지는 하트의 힘]', 6, 5, 7);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[여전히 싱싱한 플롯과 색채, 메시지]', 9, 10, 8);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[언제라도 '좋아요'라 말할 수 있다]', 9, 11, 8);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[전능한 힘을 가질 수 있으나 그러지 않겠다는 의지]', 7, 5, 8);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '김봉석');
insert into ExpertReview values (ExpertReview_seq.nextval, q'['비행'의 상징적 의미를 알려준다]', 9, 14, 8);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[순례자의 심장, 춤추는 장면, 박동하는 사운드로 초월에 다가간다]', 8, 9, 9);

insert into ExpertReview values (ExpertReview_seq.nextval, q'["나는 춤을 출 줄 아는 신만을 믿으리라"]', 9, 2, 9);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '정재현');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[통각수용기를 수시로 과부하하는 실용적 굉음]', 8, 15, 9);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[몸을 부리고, 움직이고, 쓰는 모든 순간이 사실은 '광기'였음을]', 8, 7, 9);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[환각과 악몽에 감겨 '니체의 밧줄'을 잡다]', 7, 10, 9);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '오진우');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[희망이 소멸하는 사막에서 무엇을 믿을 것인가]', 8, 16, 9);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[괴물 출현: <라초 드롬>을 <공포의 보수>로 데려가다]', 8, 3, 9);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[영화를 보고 살아남아 극장을 나오는 것까지가, 시라트]', 7, 11, 9);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '김현수');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[오직 살겠다는 각오로, 죽여준다]', 8, 17, 10);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[처질 때마다 망설임 없이 B급 호러 도파민을 쏟아붓는 샘 레이미 테마파크]', 7, 13, 10);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[편두통도 즐겁다. 카우프만의 빼어난 처방!]', 7, 10, 11);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[판타지 리얼리즘, 판타스틱 모더니즘]', 9, 3, 11);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '황진미');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[30세 이상, 연애전적 3전 이상 관람가. 사랑이란… 업보다]', 8, 17, 11);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[사랑은 기억이 아니라 존재 그 자체]', 8, 14, 11);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '이동진');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[지금 사랑 영화가 내게 줄 수 있는 모든 것]', 10, 18, 11);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[밀도 높은 긴장감에 다소 허름한 당위성]', 4, 7, 12);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[인질과 함께 결박당한 인물별 행동의 동기]', 4, 15, 12);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[악랄한 폭력과 교활한 광기가 공식대로]', 5, 10, 13);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[뒤집고 뒤집고 뒤집어 속 시원할 때까지]', 6, 3, 13);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '김연우');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[허무하지만은 않은 헛웃음. 속편의 존재 이유를 납득했다]', 7, 20, 13);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[몸서리쳐, 2026 액땜용 프레임]', 4, 10, 16);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[잔혹하고 묵직한 고자극 공포, 준비물은 흐린 눈]', 6, 5, 16);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[존재는 기억하는 쪽에 남는다]', 5, 12, 18);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[각설탕이 목에 걸린 기분]', 5, 10, 19);

insert into ExpertReview values (ExpertReview_seq.nextval, q'[허구는 힘이 세다, 그만큼 울어버렸다]', 6, 3, 19);

insert into Movie_Expert values (Movie_Expert_seq.nextval, '김수영');
insert into ExpertReview values (ExpertReview_seq.nextval, q'[익숙한 일본 감성으로 풀어낸 기억상실 로맨스]', 5, 21, 19);


insert into ExpertReview values (ExpertReview_seq.nextval, q'[해야 할 말이 신중한 이야기를 타고 퍼진다]', 6, 12, 20);
commit;